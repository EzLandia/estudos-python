from dados import *

while True:
    abrir()
    format('MENU PRINCIPAL')
    menu(['Cadastrar usuario','Notificar usuarios','Fechar sistema'])
    sel = int(input('\nSua opção: '))
    if sel == 1:
        #CADASTRO
        revenda = int(input('Revendedor (1 - Andre, 2 - Maildson, 3 - Carla.): '))
        if revenda == 1:
            arq = 'andre.txt'
        elif revenda == 2:
            arq = 'maildson.txt'
        elif revenda == 3:
            arq = 'carla.txt'
        else:
            print('Digite um revendedor válido!')
        nome = str(input('Nome: '))
        numero = int(input('Celular(DDD): '))
        vencimento = int(input('Vencimento: '))
        registro(arq,nome,numero, vencimento)
    if sel == 2:
        #MOSTRAR
        arq = 'andre.txt'
        mostrar(arq,andre)
        avisar('andre')
        '''arq = 'maildson.txt'
        mostrar(arq,maildson)
        avisar('maildson')
        arq = 'carla.txt'
        mostrar(arq,carla)
        avisar('carla')'''
    if sel == 3:
        print('Saindo do sistema.')
        browser.quit()
        break



