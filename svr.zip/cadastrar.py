from dados import *

while True:
    revenda = int(input('Revendedor (1 - Andre, 2 - Maildson, 3 - Carla.): '))
    if revenda == 1:
        arq = 'andre.txt'
    elif revenda == 2:
        arq = 'maildson.txt'
    elif revenda == 3:
        arq = 'carla.txt'
    else:
        print('Digite um revendedor válido!')
    nome = str(input('Nome: '))
    numero = int(input('Celular(DDD): '))
    vencimento = int(input('Vencimento: '))
    registro(arq, nome, numero, vencimento)