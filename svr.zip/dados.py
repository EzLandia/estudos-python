from datetime import datetime
from selenium import webdriver
from time import sleep
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys

options = Options()
options.headless = True
browser = webdriver.Firefox(options=options)

data = datetime.today().day
data = int(data)
notificados = []


def abrir():
    browser.get('https://web.whatsapp.com')
    sleep(5)
    try:
        browser.save_screenshot('code.png')
    except:
        print('Erro ao capturar tela')
    else:
        print('Aguardando login no whatsapp.')
        sleep(20)
        print('[INICIANDO VERIFICAÇÃO]\n')

def atualizar():
    print('[ ATUALIZANDO NAVEGADOR ]')
    abrir()
    sleep(30)

def menu(lista):
    c = 1
    for item in lista:
        print(f'{c} - {item}')
        c += 1


def registro(arq, nome, numero, vencimento):
    a = open(arq, 'at')
    a.write(f'{nome};{numero};{vencimento}\n')




def format(msg):
    print('-'*30)
    print(msg.center(30))
    print('-'*30)


def mostrar(arq,rev):
    try:
        a = open(arq, 'rt')
    except:
        a = open(arq, 'wt+')
    else:
        for linha in a:
            dado = linha.split(';')
            dado[2] = dado[2].replace('\n', '')
            if int(dado[2]) == data:
                print(f'{dado[0]} vence hoje!')
                rev(dado[0],dado[1])


def andre(nome,numero):
    msg = f"""%2AOi%2C%20{nome}%21%2A%0D%0ANÃO%20FIQUE%20NO%20TÉDIO%21%0D%0A%0D%0A-%20Aquele%20filme%20em%20familía%20👨%E2%80%8D👩%E2%80%8D👧%0D%0A-%20Sua%20novela%20preferida%20📺%0D%0A-%20O%20jogo%20do%20seu%20time%20⚽%0D%0A%0D%0ATudo%20isso%20você%20acompanha%20com%20a%20gente%21%0D%0A%0D%0ASeu%20plano%20irá%20vencer%20%2AAMANHÃ%2A%2C%20realize%20o%20pagamento%20e%20continue%20aproveitando%20suas%20vantagens%21%0D%0A%0D%0A%2A%2AMENSAGEM%20AUTOMÁTICA%2C%20EM%20CASO%20DE%20DÚVIDAS%20CONTATE%20SEU%20REVENDEDOR%2A"""
    try:
        browser.get(f'https://web.whatsapp.com/send?phone=55{numero}&text={msg}%21&app_absent=0')
        sleep(10)
        browser.find_element_by_xpath('/html/body/div/div[1]/div[1]/div[4]/div[1]/footer/div[1]/div[2]/div/div[2]').send_keys(Keys.ENTER)
        sleep(10)
    except:
        print(f'Houve um erro ao notificar {nome}')
    else:
        print(f'{nome} foi notificado.')
        notificados.append(nome)


def maildson(nome,numero):
    msg = f"""%2AOi%2C%20{nome}%21%2A%0D%0ANÃO%20FIQUE%20NO%20TÉDIO%21%0D%0A%0D%0A-%20Aquele%20filme%20em%20familía%20👨%E2%80%8D👩%E2%80%8D👧%0D%0A-%20Sua%20novela%20preferida%20📺%0D%0A-%20O%20jogo%20do%20seu%20time%20⚽%0D%0A%0D%0ATudo%20isso%20você%20acompanha%20com%20a%20gente%21%0D%0A%0D%0ASeu%20plano%20irá%20vencer%20%2AAMANHÃ%2A%2C%20realize%20o%20pagamento%20e%20continue%20aproveitando%20suas%20vantagens%21%0D%0A%0D%0A%2A%2AMENSAGEM%20AUTOMÁTICA%2C%20EM%20CASO%20DE%20DÚVIDAS%20CONTATE%20SEU%20REVENDEDOR%2A"""
    try:
        browser.get(f'https://web.whatsapp.com/send?phone=55{numero}&text={msg}%21&app_absent=0')
        sleep(10)
        browser.find_element_by_xpath('/html/body/div/div[1]/div[1]/div[4]/div[1]/footer/div[1]/div[2]/div/div[2]').send_keys(Keys.ENTER)
        sleep(10)
    except:
        print(f'Houve um erro ao notificar {nome}')
    else:
        print(f'{nome} foi notificado.')
        notificados.append(nome)


def carla(nome,numero):
    msg = f"""%2AOi%2C%20{nome}%21%2A%0D%0ANÃO%20FIQUE%20NO%20TÉDIO%21%0D%0A%0D%0A-%20Aquele%20filme%20em%20familía%20👨%E2%80%8D👩%E2%80%8D👧%0D%0A-%20Sua%20novela%20preferida%20📺%0D%0A-%20O%20jogo%20do%20seu%20time%20⚽%0D%0A%0D%0ATudo%20isso%20você%20acompanha%20com%20a%20gente%21%0D%0A%0D%0ASeu%20plano%20irá%20vencer%20%2AAMANHÃ%2A%2C%20realize%20o%20pagamento%20e%20continue%20aproveitando%20suas%20vantagens%21%0D%0A%0D%0A%2A%2AMENSAGEM%20AUTOMÁTICA%2C%20EM%20CASO%20DE%20DÚVIDAS%20CONTATE%20SEU%20REVENDEDOR%2A"""
    try:
        browser.get(f'https://web.whatsapp.com/send?phone=55{numero}&text={msg}%21&app_absent=0')
        sleep(10)
        browser.find_element_by_xpath('/html/body/div/div[1]/div[1]/div[4]/div[1]/footer/div[1]/div[2]/div/div[2]').send_keys(Keys.ENTER)
        sleep(10)
    except:
        print(f'Houve um erro ao notificar {nome}')
    else:
        print(f'{nome} foi notificado.')
        notificados.append(nome)


def avisar(revendedor):
    number = []
    if revendedor == 'andre':
        number.append('84996744711')
    elif revendedor == 'maildson':
        number.append('84998281083')
    elif revendedor == 'carla':
        number.append('84996744711')
    notificadosmsg = f'{notificados} foram notificados!'
    browser.get(f'https://web.whatsapp.com/send?phone=55{number[0]}&text={notificadosmsg}')
    sleep(10)
    browser.find_element_by_xpath('/html/body/div/div[1]/div[1]/div[4]/div[1]/footer/div[1]/div[2]/div/div[2]').send_keys(Keys.ENTER)
    sleep(10)
    notificados.clear()
    number.clear()