from dados import *
from datetime import datetime

hr = datetime.today().hour
mn = datetime.today().minute
jt = f'{hr}{mn}'
atual = int(jt)
print(atual)

while True:
    hr = datetime.today().hour
    mn = datetime.today().minute
    jt = f'{hr}{mn}'
    atual = int(jt)
    print(atual)
    if atual == 2046:
        abrir()
        arq = 'andre.txt'
        mostrar(arq, andre)
        avisar('andre')
        arq = 'maildson.txt'
        mostrar(arq, maildson)
        avisar('maildson')
        arq = 'carla.txt'
        mostrar(arq, carla)
        avisar('carla')
