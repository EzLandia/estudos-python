from dados import *
from datetime import datetime

meta = int(input('Qual o horario? (1200): '))
while True:
    hr = datetime.today().hour
    mn = datetime.today().minute
    jt = f'{hr}{mn}'
    atual = int(jt)
    if atual == meta:
        abrir()
        arq = 'andre.txt'
        mostrar(arq, andre)
        avisar('andre')
        arq = 'maildson.txt'
        mostrar(arq, maildson)
        avisar('maildson')
        arq = 'carla.txt'
        mostrar(arq, carla)
        avisar('carla')
